/* $Id: JiSlab.java,v 1.21 2003/08/08 12:35:38 manduchi Exp $ */
import java.io.*;
import java.util.*;

class JiSlab 
{
	public int mOffset, mSize;
	public JiSlab(int offset, int size){
	mOffset = offset;
	mSize = size;
	}
}
