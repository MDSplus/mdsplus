/* $Id: MdsIOException.java,v 1.20 2003/08/08 12:35:39 manduchi Exp $ */
public class MdsIOException extends Exception
{
    MdsIOException(String message)
    {
        super(message);
    }
}
